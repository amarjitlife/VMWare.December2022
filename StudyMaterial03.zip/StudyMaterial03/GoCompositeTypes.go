
package main

import (
    "fmt"
    "strings"
    "bufio"
    "os"
    "strconv"
    "unicode/utf8"
    "unicode"
    "io"
    "encoding/json"
    "log"
)

//___________________________________________________________

// Composite Types, the molecules created by combining the basic types 
// in various ways. We’ll talk about
// four such types
// 	arrays, structs, slices, maps

// Arrays and structs are aggregate types; 
// 		Their values are concatenations of other values in memory. 
//		Arrays are homogeneous—their elements all have the same type—
//		whereas structs are heterogeneous. 

//	Both arrays and structs are fixed size. 
//	In contrast, slices and maps are dynamic data structures that 
//		grow as values are added.

//___________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func playWithArrays() {
	
	// Creating Array Of 3 Members
	//		Index Starts From 0 To len - 1 i.e. [0, len)
	//		All Elements Of Array Initialised To Zeros Of Type

	var a [3]int

	for index, value := range a {
		fmt.Printf("\nAt Index: %d Value: %v", index, value)
	}

	fmt.Println()

	fmt.Println( a[0] )
	fmt.Println( a[1] )
	fmt.Println( a[2])
	fmt.Println( a[ len( a ) - 1])

	// invalid argument: array index 3 out of bounds [0:3]
	// fmt.Println( a[ len( a ) ] )

	for _, value := range a {
		fmt.Printf("\nValue: %v", value)
	}

	var q [5]int = [5]int{ 10, 20, 30, 40, 50 }
	var r [5]int = [5]int{ 10, 20, 30 }

	fmt.Println("Array Length : ", len(q) )
	for index, value := range q {
		fmt.Printf("At index: %d value: %d\n", index, value)
	}

	fmt.Println("Array Length : ", len(r) )
	for index, value := range r {
		fmt.Printf("At index: %d value: %d\n", index, value)
	}

	// var qq [5]int = { 10, 20, 30, 40, 50 }
	// var rr [5]int = { 10, 20, 30 }

	var q1 = [5]int{ 10, 20, 30, 40, 50 }
	var r1 = [5]int{ 10, 20, 30 }

	for index, value := range q1 {
		fmt.Printf("At index: %d value: %d\n", index, value)
	}

	fmt.Println("Array Length : ", len(r) )
	for index, value := range r1 {
		fmt.Printf("At index: %d value: %d\n", index, value)
	}

	// [...] Means Compiler Will Deduce Array Size From Initialisation List
	// s Type Will Be [4]int
	s := [...]int{ 10, 20, 100, 111 }
	fmt.Println("Array Length : ", len(s) )
	fmt.Printf( "Data Type : %T \n", s )

	for index, value := range s {
		fmt.Printf("At index: %d value: %d\n", index, value)		
	}

	some := [3]int { 100, 200, 300 }
	fmt.Printf( "Data Type : %T \n", some )

	someAgain := [...]int{ 99 : -1  }
	// for index, value := range someAgain {
	// 	fmt.Printf("At index: %d value: %d\n", index, value)
	// }

	fmt.Println("Array Length : ", len( someAgain ) )
	fmt.Printf( "Data Type : %T \n", someAgain )

	aa := [2]int{ 10, 20 }
	bb := [...]int{ 10, 20 }
	cc := [2]int{ 10, 30 }
	ff := [2]float32 { 10.0, 20.0 }

	fmt.Println( aa == bb, aa == cc, bb == cc )
	// true false false

	// invalid operation: aa == ff (mismatched types [2]int and [2]float32)
	// fmt.Println( aa == ff )
	fmt.Println( ff )

	dd := [3]int{ 10, 30 }
	fmt.Println( dd )

	// invalid operation: aa == dd (mismatched types [2]int and [3]int)
	// fmt.Println( aa == dd )
}


//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

type Flags uint

const ( // STATUS BITs ARE DEFINED AS FOLLOWS
    FlagUp Flags = 1 << iota // is up
	FlagBroadcast		 	 // supports broadcast access capability
	FlagLoopback             // is a loopback interface
	FlagPointToPoint         // belongs to a point-to-point link
	FlagMulticast            // supports multicast access capability
)

func IsUp(v Flags) bool     { return v & FlagUp == FlagUp } // & (bitwise AND)
func TurnDown(v *Flags)     { *v &^= FlagUp }   // &^ (AND NOT): 
												// This is a bit clear operator.
func SetBroadcast(v *Flags) { *v |= FlagBroadcast } // | (bitwise OR)
func IsCast(v Flags) bool   { return v & (FlagBroadcast | FlagMulticast) != 0 }

func playWithFlags() {
	var v Flags = FlagMulticast | FlagUp
	fmt.Printf("%b %t\n", v, IsUp(v)) // "10001 true"
	
	// Passing Reference Of v
	TurnDown( &v )
	fmt.Printf("%b %t\n", v, IsUp(v)) // "10000 false"
	
	// Passing Reference Of v
	SetBroadcast( &v )
	fmt.Printf("%b %t\n", v, IsUp(v))   // "10010 false"
	fmt.Printf("%b %t\n", v, IsCast(v)) // "10010 true"
}

//___________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func doChangeAgain1( a [10]int ) {
	for i, _ := range a {
		a[i] = 100
	}
}

// Following Function Takes Argument:
//		Passing Array Reference
func doChangeAgain2( a *[10]int ) {
	for i, _ := range a {
		a[i] = 100
	}
}

// Following Function Takes Argument:
//		Passing Array Slice
// Slices Are Pass By Reference
func doChangeAgain3( slice []int ) {
	for i, _ := range slice {
		slice[i] = 111
	}
}

func printArray( a [10]int ) {
	fmt.Println()
	for i, _ := range a {
		fmt.Printf("  %d  ", a[i])
	}	
}

// In Go 		- Arrays Are Pass By Value By Default
// In C/C++/Java- Arrays Are Pass By Reference By Default
func playWithDoChangeAgain() {
	var array [10]int = [10]int { 10, 20, 30, 40, 50 }

	fmt.Println("\nArrays Passed By Value...")
	printArray( array )
	doChangeAgain1( array )
	printArray( array )

	var array1 [10]int = [10]int { 10, 20, 30, 40, 50 }
	fmt.Println("\nArrays Passed By Reference...")
//	Passing Array Reference
	printArray( array1 )
	doChangeAgain2( &array1 )
	printArray( array1 )

	var array2 [10]int = [10]int { 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 }
	fmt.Println("\nArrays Passed By Slice...")
// 	Slices Are Pass By Reference
//		Passing Array Slice Refering All Elements
	printArray( array2 )
	doChangeAgain3( array2[ : ] )
	printArray( array2 )

	array2 = [10]int { 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 }
	fmt.Println("\nArrays Passed By Slice...")
// 	Slices Are Pass By Reference
//		Passing Array Slice Refering All Elements
	printArray( array2 )
	doChangeAgain3( array2[ : 4 ] )
	printArray( array2 )

	array2 = [10]int { 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 }
	fmt.Println("\nArrays Passed By Slice...")
// 	Slices Are Pass By Reference
//		Passing Array Slice Refering All Elements
	printArray( array2 )
	doChangeAgain3( array2[ 6 :  ] )
	printArray( array2 )

	array2 = [10]int { 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 }
	fmt.Println("\nArrays Passed By Slice...")
// 	Slices Are Pass By Reference
//		Passing Array Slice Refering All Elements
	printArray( array2 )
	doChangeAgain3( array2[ 3 : 7 ] )
	printArray( array2 )
}

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func playWithSlices() {

	// 	Thus the slice months[1:13] refers to the whole range of valid months, 
	//	slice months[0 : 13] or months[ : ] will access whole of the array elements
	// 	as does the slice months[1:]; the slice months[:] refers to the whole array.

	months := [...]string{ 0 : "", "Jan", "Feb", "Mar", "Apr", "May",
					"Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" }

	fmt.Println("Months : ", months)

	quater1 := months[ 1 : 4 ]
	quater2 := months[ 4 : 7 ]
	summer  := months[ 2 : 7 ]

	fmt.Println("Quater1 :", quater1)
	fmt.Println("Quater2 :", quater2)
	fmt.Println("Summer  :", summer)

	for _, s := range summer {
		for _, q := range quater2 {
			if s == q {
				fmt.Printf(" %s Appears In Both \n", s)
			}
		}
	}

	fmt.Printf("Array Slices Type : %T %T %T\n", quater1, quater2, summer )

	// invalid operation: quater1 == quater2 (slice can only be compared to nil)
	// fmt.Println( quater1 == quater2, summer == quater2 )

	// Compiler Can Do Optimisation : String Kerning
	//		String Literal Values Are Stored One Copy
	//		Generally In Code Areas
	// String Values Are Immutable
	greeting 		:= "Good Evening! Good"
	greetingAgain 	:= "Good Evening! Good"

	fmt.Println(greeting, greetingAgain)

	// Slices Syntax But Giving Substrings Of string Type
	first 	:= greeting[ 1 : 4 ]
	last  	:= greeting[ 5 :   ]
	between := greeting[ 2 : 6 ]

	fmt.Println( greeting )
	fmt.Println( first )
	fmt.Println( last )
	fmt.Println( between )

	fmt.Println( first == last, first == between )

	firstGood := greeting[ : 4 ]
	lastGood  := greeting[ len(greeting) - 4 :  ]
	
	fmt.Printf("String Slices Type : %T %T\n", firstGood, lastGood )

	fmt.Println( firstGood, lastGood, len( firstGood ), len( lastGood ) )
	fmt.Println( firstGood == lastGood )

	// cannot assign to greeting[0] (value of type byte)
	// greeting[0] = "#"
}


//__________________________________________________________________________________
// 						
// 								GO SLICES CONCEPTS
//__________________________________________________________________________________

// Slices represent variable-length sequences whose elements all have the same type. 
// A slice type is written []T, where the elements have type T; 
// 		it looks like an array type without a size.

// A slice is a lightweight data structure that gives access to a subsequence 
// (or perhaps all) of the elements of an array, which is known as the slice’s 
// underlying array. 

// 	A slice has three components: a pointer, a length, and a capacity. 
// 		The pointer points to the first element of the array that is reachable 
// 			through the slice, which is not necessarily the array’s first element. 
// 		The length is the number of slice elements; it can’t exceed the capacity, 
// 			which is usually the number of elements between 
// 			the start of the slice and the end of the underlying array. 

// 		The built-in functions len and cap return those values.

//  The slice operator s[ i : j ], where 0 ≤ i ≤ j ≤ cap(s), 

// 	Creates a new slice that refers to elements i through j-1 of the sequence s, 
// 		which may be an array variable, a pointer to an array, or another slice. 

// 	The resulting slice has j-i elements. 
// 	If i is omitted,it’s 0,and if j isomitted, it’s len(s). 


//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func reverse( slice []int ) {
	for i, j := 0, len(slice) - 1  ;  i < j  ;  i, j = i + 1, j - 1 {
		slice[i], slice[j] = slice[j], slice[i]
	}
}

// Following Function Takes Argument:
//		Passing Array Slice
// Slices Are Pass By Reference
func doChangeAgain4( slice []int ) {
	for i, _ := range slice {
		slice[i] = 111
	}
}

func slicesEqual( x, y []int ) bool {
	if len( x ) != len ( y ) { return false }

	for i := range x {
		if x[i] != y[i] { return false }
	}
	return true
}

func playWithArrayAndSlices() {
	a := [...]int { 10, 20, 30, 40, 50, 60, 70, 80, 99 }

	fmt.Println( a )
	reverse( a[ : ] )
	fmt.Println( a )

	// Creating Slice Using Literal Syntax
	// s Is A Slice
	//		Array Syntax Without Size Information
	s := []int { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }

	fmt.Println( s )
	// s[ : 5 ] Is Slice Over A Slice s 
	reverse( s[ : 5 ] )
	fmt.Println( s )
	reverse( s[ 5 :  ] )
	fmt.Println( s )

	doChangeAgain4( s[ 3 : 6 ] )
	fmt.Println( s )

	slice1 := a[ 2 : 6 ]
	slice2 := a[ 2 : 6 ]
	slice3 := a[ 5 : 8 ]

	// fmt.Println( slice1 == slice2 )
	// fmt.Println( slice1 == slice3 )

	fmt.Println( slicesEqual( slice1, slice2 ) )
	fmt.Println( slicesEqual( slice1, slice3 ) )
	fmt.Println( slicesEqual( slice2, slice3 ) )

	// greeting := "Good Morning! Good Good!!!"
	// var ss []string = greeting[ : ]
}

//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func playWithSlicesFunctions() {

// The built-in function make creates a slice of a specified element 
// 		type, length, and capacity.

// The capacity argument may be omitted, in which case the capacity 
//   equals the length.
// 		make([]T, len)
// 		make([]T, len, cap) // same as make([]T, cap)[:len]

	// Background Array of Size 3 Allocated
	s := make( []string, 3 )

	fmt.Println("Empty Slice : ", s)
	fmt.Printf("Slice Type:  %T \n", s)
	fmt.Printf("Slice Length:  %d  Capacity : %d\n", len(s), cap(s))

	s[0] = "a"
	s[1] = "b"
	s[2] = "c"

	fmt.Println("Empty Slice : ", s)
	fmt.Println("Slice Element: ", s[2])

	// Background Array of Length 4 Allocated
	s = append( s, "d" )
	fmt.Println("Slice Value:", s)
	fmt.Printf("Slice Length:  %d  Capacity : %d\n", len(s), cap(s))

	s = append( s, "d", "E", "F", "G", "H" )
	fmt.Println("Slice Value:", s)
	fmt.Printf("Slice Length:  %d  Capacity : %d\n", len(s), cap(s))

	s = append( s, "dd", "EE", "FF" )
	fmt.Println("Slice Value:", s)
	fmt.Printf("Slice Length:  %d  Capacity : %d\n", len(s), cap(s))

	s = append( s, "d", "E", "F", "G", "H", "1", "2", "3", "4" )
	fmt.Println("Slice Value:", s)
	fmt.Printf("Slice Length:  %d  Capacity : %d\n", len(s), cap(s))

	//___________________________________________________________________

	ss := make( []string, 3 )

	fmt.Println("Empty Slice : ", ss)
	fmt.Printf("Slice Type:  %T \n", ss)
	fmt.Printf("Slice Length:  %d  Capacity : %d\n", len(ss), cap(ss))

	ss[0] = "AA"
	ss[1] = "BB"
	ss[2] = "CC"
	fmt.Println("Slice Value:", ss)
	fmt.Printf("Slice Length:  %d  Capacity : %d\n", len(ss), cap(ss))

	cc := make( []string, len( ss ) )
	fmt.Println("Slice Value:", cc)
	fmt.Printf("Slice Length:  %d  Capacity : %d\n", len(cc), cap(cc))

	// Shallow Copy
	cc = ss // Reference Assignment

	fmt.Println("Slice Value:", ss)
	fmt.Println("Slice Value:", cc)

	ss[0] = "Hello!"

	fmt.Println("Slice Value:", ss)
	fmt.Println("Slice Value:", cc)	

	ss = append( ss, "GG", "HH" )

	fmt.Println("Slice Value:", ss)
	fmt.Println("Slice Value:", cc)	
	fmt.Printf("Slice Length:  %d  Capacity : %d\n", len(ss), cap(ss))
	fmt.Printf("Slice Length:  %d  Capacity : %d\n", len(cc), cap(cc))

	sss := make( []string, 0 )

	fmt.Println(">>> ss Slice: ",  sss )
	// fmt.Println(">>>>ss Slice Element ss[0]: ",  ss[0] )

	sss = append( sss, "AA", "BB", "CC", "DD", "EE", "FF")

	ccc := make( []string, len( sss ) )

	fmt.Println("ss Slice: ",  sss )
	fmt.Println("cc Slice: ",  ccc )

	// Deep Copy: Full Copy Of The Object Get Created
	copy( ccc, sss )

	fmt.Println("ss Slice: ",  sss )
	fmt.Println("cc Slice: ",  ccc )

	sss[0] = "Good Morning!!!"

	fmt.Println("ss Slice: ",  sss )
	fmt.Println("cc Slice: ",  ccc )

	// 
	tt := []string{ "Ding", "Dong", "Ming", "Mong" }
	fmt.Println("tt Slice: ",  tt )
	fmt.Printf("tt Slice Type : %T",  tt )
}

//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// Type Ctrl+D To Append EoF In Given Input

func playWithReadingInputs() {

	input := bufio.NewScanner( os.Stdin )

	outer: // Labeling For Loop
		for input.Scan() {
			var ints []int

			for _, s := range strings.Fields( input.Text() ) {
				x, err := strconv.ParseInt( s, 10, 64 )
				
				if err != nil {
					fmt.Fprintln( os.Stderr, err )
					continue outer // Jumping To Label outer
				}
				ints = append( ints, int(x) )
			}

			fmt.Printf( "%v\n", ints )
			reverse( ints  )
			fmt.Printf( "%v\n", ints )
		}
}

//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func playWith2DimentionalData() {
	twoDimentionalArray := make( [][]int, 3 )

	for i := 0 ; i < 3 ; i++ {
		innerLen := i + 1

		twoDimentionalArray[ i ] = make( []int, innerLen ) 
		for j := 0 ; j < innerLen ; j++ {
			twoDimentionalArray[i][j] = i + j
		}
	}

	fmt.Println("2 Dimentional Array:", twoDimentionalArray )
}


//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// Conceptual Example Of Slice's append Function Internal Working
//		Conceptual Example Of Dynamic Array Implementation Using Slices
func appendInt( x []int, y int ) []int {
	var z []int

	zlen := len(x) + 1
	if zlen <= cap(x) {
		z = x[ : zlen ]
	} else { // Underlining Array Is Full
		// When Array Is Full, Allocate A New Array
		//	To Append Additional Data
		zcap := zlen
		if zcap < 2 * len(x) {
			zcap = 2 * len(x) 	// Pool Size Increased
		}
		
		z = make( []int, zlen, zcap )
		copy(z, x)
	}

	z[ len( x ) ] = y
	return z
}

func playWithAppendInt() {
	var x, y []int

	for i := 0 ; i < 10 ; i++ {
		y = appendInt(x, i)
		fmt.Printf( " %d Capacity=%d \t %v \n", i, cap(y), y )
		x = y
	}
}


//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// Varidiac Functions With Varidiac Arguments
// 		Function Which Takes Variable Number Of Arguments
//		Here ... Before Type Means It Takes Variable Number Of Arguments

// HOME WORK

// Polymorphic Function
//		Mechanism : Variadiac Arguments
func summation( numbers ...int ) int {
	fmt.Print( numbers )
	total := 0

	for _, number := range numbers {
		total = total + number 
	}

	return total
}

func playWithSummation() {
	var result int

	result = summation() 
	fmt.Println("\n Result : ", result )

	result = summation( 111 )
	fmt.Println("\n Result : ", result )

	result = summation( 10, 20, 30, 40, 50 )
	fmt.Println("\n Result : ", result )

	result = summation( 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 )
	fmt.Println("\n Result : ", result )

	numbers := []int{ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }
	result = summation( numbers... )
	fmt.Println("\n Result : ", result )
}

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// HOME WORK
func appendSlice( x []int, y ...int ) []int {
	var z []int

	zlen := len(x) + len( y )
	if zlen <= cap(x) {
		z = x[ : zlen ]
	} else { // Underlining Array Is Full
		// When Array Is Full, Allocate A New Array
		//	To Append Additional Data
		zcap := zlen
		if zcap < 2 * len(x) {
			zcap = 2 * len(x) 	// Pool Size Increased
		}
		
		z = make( []int, zlen, zcap )
		copy(z, x)
	}
	copy( z[ len(x) : ], y )
	return z
}

func playWithAppendSlices() {
	var x, y []int

	for i := 0 ; i < 10 ; i++ {
		y = appendSlice(x, i)
		fmt.Printf( " %d Capacity=%d \t %v \n", i, cap(y), y )
		x = y
	}
	fmt.Println( x )

	x = appendSlice(x , 10, 20, 30 )
	fmt.Println( x )

	x = appendSlice(x , 11, 22, 33, 44, 55, 66 )
	fmt.Println( x )

	numebrs := []int{ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }
	x = appendSlice( x, numebrs... )
	fmt.Println( x )	
}

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// HOME WORK
func filterEmpty( strings []string ) []string {
	i := 0
	for _, s := range strings {
		if s != "" {
			strings[i] = s
			i++
		}
	}
	return strings[ : i ]
}

func filterEmptyAgain( strings []string ) []string {
	out := strings[ : 0 ] // Zero Length Slice Of Original
	for _, s := range strings {
		if s != "" {
			out = append( out, s )
		}
	}
	return out
}

func playWithNonEmpty() {
	data := []string{ "one", "", "two", "ding", "", "ting" }
	fmt.Printf("%q \n", data)	
	filteredData := filterEmpty( data )
	fmt.Printf("%q \n", filteredData )

	dataAgain := []string{ "111", "", "", "9999", "", "Data", "" }
	fmt.Printf("%q \n", dataAgain)	
	filteredDataAgain := filterEmptyAgain( dataAgain )	
	fmt.Printf("%q \n", filteredDataAgain )
}

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func playWithMaps() {
	m := make( map[string]int )

	m["k1"] = 7
	m["k2"] = 13

	fmt.Println("Map: ", m)

	v1 := m["k1"]
	fmt.Println("Map Key Value: ", v1)

	fmt.Println("Map Length :", len( m ) )
	delete(m, "k2")
	fmt.Println("Map: ", m)

	value, status := m["k2"]	
	fmt.Println("Map Key Value: ", value, status )

	// Literal Syntax To Create Map
	mm := map[string]int{ "foo" : 1, "bar" : 2 }
	fmt.Println("Map: ", mm)
}

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// HOME WORK

func removeDuplicates() {
	seen := make( map[string]bool ) // a set of strings
	input := bufio.NewScanner( os.Stdin )

	for input.Scan() {
		line := input.Text()
		if !seen[line] {
			seen[line] = true
			// fmt.Println(line)
		}
	}

	if err := input.Err(); err != nil {
		fmt.Fprintf(os.Stderr, "removeDuplicates: %v\n", err)
		os.Exit(1)
	}

	fmt.Println( seen )	
}

//___________________________________________________________________

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// HOME WORK
// Test Input
// 		Hello Hello Hello Hello Hello 早上好

func countUnicodeCharacters() {
	counts := make(map[rune]int)    // counts of Unicode characters
	var utflen [utf8.UTFMax + 1]int // count of lengths of UTF-8 encodings
	invalid := 0                    // count of invalid UTF-8 characters

	in := bufio.NewReader(os.Stdin)
	for {
		r, n, err := in.ReadRune() // returns rune, nbytes, error
		if err == io.EOF {
			break
		}
		if err != nil {
			fmt.Fprintf(os.Stderr, "charcount: %v\n", err)
			os.Exit(1)
		}
		if r == unicode.ReplacementChar && n == 1 {
			invalid++
			continue
		}
		counts[r]++
		utflen[n]++
	}
	fmt.Printf("rune\tcount\n")
	for c, n := range counts {
		fmt.Printf("%q\t%d\n", c, n)
	}
	fmt.Print("\nlen\tcount\n")
	for i, n := range utflen {
		if i > 0 {
			fmt.Printf("%d\t%d\n", i, n)
		}
	}
	if invalid > 0 {
		fmt.Printf("\n%d invalid UTF-8 characters\n", invalid)
	}
}


//___________________________________________________________________
//
//						GO STRUCT
//___________________________________________________________________

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// HOME WORK 
// Circle Type Have Three Members
type Circle struct {
	X, Y, Radius int 
}

// Circle Type Have Four Members
type Wheel struct {
	X, Y, Radius, Spokes int
}

func playWithCircleAndWheel() {
	var c Circle
	c.X = 10 
	c.Y = 20
	c.Radius = 50

	fmt.Println("Circle :", c )

	var w Wheel
	w.X = 11 
	w.Y = 22
	w.Radius = 55
	w.Spokes = 24

	fmt.Println("Wheel :", w )
}

//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

type Point1 struct {
	X int
	Y int
}

// Composing Types
type Circle1 struct { 
	Center Point1  // Embedding Object Of Another Types
	Radius int 
}

type Wheel1 struct {
	Circle Circle1 // Embedding Object Of Another Types
	Spokes int
}

func playWithCircleAndWheel1() {
	var c Circle1 // c Is Instance Of Circle1 Types
	c.Center.X = 10 
	c.Center.Y = 20
	c.Radius = 50

	fmt.Println("Circle1 :", c )
	// c.X = 100 
	// c.Y = 200
	// c.Radius = 500
	// fmt.Println("Circle1 :", c )

	var w Wheel1
	w.Circle.Center.X = 11 
	w.Circle.Center.Y = 22
	w.Circle.Radius = 55
	w.Spokes = 24

	fmt.Println("Wheel1 :", w )
	// w.X = 111 
	// w.Y = 222
	// w.Radius = 555
	// w.Spokes = 244

	// fmt.Println("Wheel1 :", w )
}

//__________________________________________________________________

// struct Creates Associative Types
//		Type Of Types

type Point struct {
	X int 
	Y int
}

func ScalePoint( point Point, factor  int) Point {
	return Point{ point.X * factor, point.Y * factor }
}

func AddPoint( point1 Point, point2 Point ) Point {
	return Point{ point1.X + point2.X , point1.Y +point2.Y }
}

func playWithPointType() {
	point1 := Point{ 10, 20 }
	point2 := Point{ 100, 200 }
	point3 := Point{ 10, 20 }

	fmt.Println( "point1 : ", point1 )
	fmt.Println( "point2 : ", point2 )
	fmt.Println( "point3 : ", point3 )

	fmt.Println( point1.X == point2.X && point1.Y == point2.Y )
	fmt.Println( point1.X == point3.X && point1.Y == point3.Y )

	// Equality Works For struct Type Also.
	//		It Will Compare Members Of struct
	fmt.Println( "point1 == point2 : ", point1 == point2 )
	fmt.Println( "point1 == point3 : ", point1 == point3 )

	fmt.Println( "point1 *  5 : ", ScalePoint( point1, 5 )  )
	fmt.Println( "point2 * 10 : ", ScalePoint( point2, 10 ) )
	fmt.Println( "point3 *  2 : ", ScalePoint( point3, 2 ) )

	point4 := AddPoint( point1, point2 )
	fmt.Println( "point4 : ", point4 )

	point5 := AddPoint( point1, point3 )
	fmt.Println( "point5 : ", point5 )
}

//__________________________________________________________________

type Point2 struct {
	X int
	Y int
}

type Circle2 struct {
	Point2 			// Type/Structure Embedding
	Radius int
}

type Wheel2 struct {
	Circle2  		// Type/Structure Embedding
	Spokes int 
}

func playWithCircle2AndWheel2() {
	var w Wheel2
	// I Will Always Prefer Following Initialisation Style
	w.Circle2.Point2.X = 11
	w.Circle2.Point2.Y = 22
	w.Circle2.Radius   = 55
	w.Spokes = 24

	fmt.Println("Wheel : ", w)

	// Can Access Directly Members Of Embedded Type/Structure
	w.X 		= 110
	w.Y 		= 220
	w.Radius  	= 550
	w.Spokes 	= 240

	fmt.Println("Wheel : ", w)

	var ww Wheel2
	ww = Wheel2{ Circle2{ Point2{ 88, 99}, 77 }, 44 }
	fmt.Println("Wheel : ", ww)

	// Readable Initialisation Using Labels And Nested Initialisation Blocks
	ww = Wheel2 {
			Circle2 : Circle2 {
				Point2 : Point2 { 888, 999 },
				Radius : 777,
			},
			Spokes : 444,			
		}

	fmt.Println("Wheel : ", ww)
}

//__________________________________________________________________

type Point3 struct {
	X int
	Y int
}

type Circle3 struct {
	Point3 			// Type/Structure Embedding
	Radius int
}

type Wheel3 struct {
	Circle3  		// Type/Structure Embedding
	Spokes int 
	X int
	Y int
}

func playWithCircle3AndWheel3() {
	var w Wheel3
	// I Will Always Prefer Following Initialisation Style
	w.Circle3.Point3.X = 11
	w.Circle3.Point3.Y = 22
	w.Circle3.Radius   = 55
	w.Spokes = 24
	w.X = -90
	w.Y = -99

	fmt.Println("Wheel : ", w)

	// // Can Access Directly Members Of Embedded Type/Structure
	w.X 		= 110
	w.Y 		= 220
	w.Radius  	= 550
	w.Spokes 	= 240
	w.X = -900
	w.Y = -999

	fmt.Println("Wheel : ", w)

// Function : playWithCircle3AndWheel3
// Wheel :  {{{11 22} 55} 24 -90 -99}
// Wheel :  {{{11 22} 550} 240 -900 -999}
}

//__________________________________________________________________
//__________________________________________________________________

type Movie struct {
	Title string
	Year int 		`json:"Released Year"`
	Color bool 		`json:"Movie Color"`
	Actors []string
}


func playWithMoviesMarshallingAndUnmarshalling() {
	var movies = []Movie {
		{
			Title: "Shole",
			Year: 1990,
			Color: true,
			Actors: []string {
				"Dharam Paaji",
				"Amitaab",
				"Basanti",
				"Gabbar Singh",
			},
		},
		{
			Title: "Bajarangi Bhaijaan",
			Year: 2010,
			Color: true,
			Actors: []string {
				"Salman Khan",
				"Nawajudin Sidqui",
				"Little Girl",
			},
		},
		{
			Title: "Mugle Azaam",
			Year: 1960,
			Color: true,
			Actors: []string {
				"Madhu Bala",
				"Dilip Kumar",
				"Prithi Raj",
			},
		},
		{
			Title: "Ding Dong",
			Year: 2000,
			Color: false,
			Actors: []string {
				"AAAA",
				"BBBB",
				"CCCCC",
				"DDDDDD",
			},
		},
	}

	for index, movie := range movies {
		fmt.Println( index, movie )
	}

	{ // Local Scope
		jsonData, err := json.Marshal( movies )
		if err != nil {
			log.Fatalf("JSON Marshalling Failed... %s", err)
		} 
		fmt.Printf("JSON DATA: %s \n", jsonData)
	}

	jsonData, err := json.MarshalIndent( movies, "", "  " )
	if err != nil {
		log.Fatalf("JSON Marshalling Failed... %s", err)
	} 
	fmt.Printf("JSON DATA: %s \n", jsonData)


	var moviesTitle []struct { Title string }

	if err := json.Unmarshal( jsonData, &moviesTitle ) ; err != nil {
		log.Fatalf("JSON Marshalling Failed... %s", err)		
	}
	fmt.Printf("UNMARSHED DATA: %s \n", moviesTitle)

	var moviesData []Movie
	
	if err := json.Unmarshal( jsonData, &moviesData ) ; err != nil {
		log.Fatalf("JSON Marshalling Failed... %s", err)		
	}
	fmt.Println("UNMARSHED DATA: ", moviesData)

	// To unmarshal a JSON array into a slice, Unmarshal resets the slice length to zero and 
	// then appends each element to the slice. As a special case, to unmarshal an empty JSON array 
	// into a slice, Unmarshal replaces the slice with a new empty slice.

	// if err := json.Unmarshal( jsonData, moviesData ) ; err != nil {
	// 	log.Fatalf("JSON Marshalling Failed... %s", err)		
	// }
	// fmt.Println("UNMARSHED DATA: ", moviesData)
}

//__________________________________________________________________
//__________________________________________________________________
//__________________________________________________________________
//__________________________________________________________________
//__________________________________________________________________
//__________________________________________________________________
//__________________________________________________________________
//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func main() {
	fmt.Println("\nFunction : playWithArrays")
	playWithArrays()

	fmt.Println("\nFunction : playWithFlags")
	playWithFlags()

	fmt.Println("\nFunction : playWithDoChangeAgain")
	playWithDoChangeAgain()

	fmt.Println("\nFunction : playWithSlices")
	playWithSlices()

	fmt.Println("\nFunction : playWithArrayAndSlices")
	playWithArrayAndSlices()

	fmt.Println("\nFunction : playWithSlicesFunctions")
	playWithSlicesFunctions()

	// fmt.Println("\nFunction : playWithReadingInputs")
	// playWithReadingInputs()

	fmt.Println("\nFunction : playWith2DimentionalData")
	playWith2DimentionalData()

	fmt.Println("\nFunction : playWithAppendInt")
	playWithAppendInt()

	fmt.Println("\nFunction : playWithSummation")
	playWithSummation()

	fmt.Println("\nFunction : playWithAppendSlices")
	playWithAppendSlices()

	fmt.Println("\nFunction : playWithNonEmpty")
	playWithNonEmpty()

	fmt.Println("\nFunction : playWithMaps")
	playWithMaps()

	// fmt.Println("\nFunction : removeDuplicates")
	// removeDuplicates()

	// fmt.Println("\nFunction : countUnicodeCharacters")
	// countUnicodeCharacters()

	fmt.Println("\nFunction : playWithCircleAndWheel")
	playWithCircleAndWheel()

	fmt.Println("\nFunction : playWithCircleAndWheel1")
	playWithCircleAndWheel1()

	fmt.Println("\nFunction : playWithPointType")
	playWithPointType()

	fmt.Println("\nFunction : playWithCircle2AndWheel2")
	playWithCircle2AndWheel2()

	fmt.Println("\nFunction : playWithCircle3AndWheel3")
	playWithCircle3AndWheel3()

	fmt.Println("\nFunction : playWithMoviesMarshallingAndUnmarshalling")
	playWithMoviesMarshallingAndUnmarshalling()

	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")

}

