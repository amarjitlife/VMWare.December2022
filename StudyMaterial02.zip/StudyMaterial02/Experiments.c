
#include <stdio.h>
#include <limits.h>

// BAD DESIGN
int unsafeSum( int x, int y ) {
	return x + y;
}

//_________________________________________________________


// GOOD DESIGN
// Platform Independent Code
//		Type Safe Code
signed int sum(signed int x, signed int y) {
	  signed int sum = 0;
	  // Type Safe Code
	  //	Respect Type Definition
	  if (((y > 0) && (x > (INT_MAX - y))) ||
	      ((y < 0) && (x < (INT_MIN - y)))) {
			printf("\nCan't Calculate Sum For Given Values");
	  } else {
			sum = x + y;
			return sum;
	  }
}

//_________________________________________________________

// ASCII CODE
char ch = 'A';

void playWithIfElse() {
	// char thirdBit = ch & 0000100;
	int x = -10;

	// Value To Value Conversion Happening
	//		int Value Getting Converted To Boolean Value

	// Expression Evaluated To Non Zero int Value
	//		It's Converted To True
	// Expression Evaluated To Zero int Value
	//		It's Converted To False

	// if (Expression) { } else { }
	// if ( x = 100 ) {

	if ( x ) {
		printf("\nOye Hoye!!!");
	} else {
		printf("\nWah Wah!!!");
	}
}

void playWithIfElseAgain() {
	int x = -10;
	int y = 0;

	if ( x ) {  y = 99; } else { y = 111; }

	y = ( x ) ?  99 : 111;
}

//_________________________________________________________

// DESIGN PRINCIPLE
// 		You Should Not Pay For It! If You Are Not Using It!

void playWithTypes() {
	signed char ch = 0; // Default Range char Type : [-128, 127]
	
	unsigned char ch1 = 0 ; // Range char Type : [0, 255]

	for ( char ch = 0 ; ch < 256 ; ch++ ) {
		printf(" %c %d ", ch, ch);
	}

	float f1 = 3.888998999, f2 = 3.88899877777676867;

	if ( f1 == f2 ) { // Don't Compare Floating Points With Equality
		printf("Both Are Equal!");
	} else {
		printf("Both Are UnEqual!");		
	}
}

//_________________________________________________________

void playWithCharArray() {
	char greeting[] = "Good Morning!";

	for( int i = 0 ; greeting[i] != '\0' ; i++ ) {
		printf(" %c ", greeting[i] );
	}
}

//_________________________________________________________

// DESIGN PRINCIPLE
// 		You Should Not Pay For It! If You Are Not Using It!

void playWithArray() {
	int a[5] = { 10, 20, 30, 40, 50 };
	
	for( int i = 0 ;  i < 10 ; i++ ) {
		printf(" %d ", a[i] );
	}
}

//_________________________________________________________

// Choices Are:
// 20 30 80 CTE RTE NoT

void doChange1( int * ptr ) {
	int b = 30;
	ptr = &b;
	b = b + 50;
}

void doChange2( int * ptr ) {
	int b = 30;
	*ptr = b + 50;
}

// BAD CODE
void doChange3( int ** ptr ) {
	int c = 100;
	int b = 30;
	**ptr = b + 50;
	
	// BAD CODE: Assigning Address Of Local Variable
	//		Local Will Get Deallocated Moment You Come Out Of Function
	*ptr = &c;
}

void playWithDoChange() {
	int a = 20;
	// Pointer Variables
	//		Variable Storing Address
	// ptr Stores Reference/Pointer/Address Of Variable int Type
	int * ptr = &a; // & Operator : Address Of a
	
	// Passing
	//		a Is Pass By Reference.
	//		ptr Is Pass By Value
	doChange1( ptr );

	printf("\nResult : %d", a);
	printf("\nResult : %d", *ptr);

// Result : 20
// Result : 20
	// Passing
	//		a Is Pass By Reference.
	//		ptr Is Pass By Value
	doChange2( ptr );

	printf("\nResult : %d", a);
	printf("\nResult : %d", *ptr);
// Result : 80
// Result : 80

	// Passing
	//		a Is Pass By Reference.
	//		ptr Is Pass By Reference
	doChange3( &ptr );

	printf("\nResult : %d", a);
	printf("\nResult : %d", *ptr);
// Result : 80
// Result : 100 ( GARABAGE )
}

//_________________________________________________________


void doChangeAgain( int a[], int size ) {
	for ( int i = 0 ; i < size ; i++ ) {
		a[i] = 100;
	}
}

void printArray( int a[], int size ) {
	for ( int i = 0 ; i < size ; i++ ) {
		printf("  %d  ",  a[i]);
	}
}

void playWithDoChangeAgain() {
	int array[5] = { 10, 20, 30, 40, 50 };
	int arraySize = 5;

	printArray( array, arraySize );

	doChangeAgain( array, arraySize );

	printArray( array, arraySize );
}

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________

int main() {
	printf("\n Function : playWithIfElse");
	playWithIfElse();

	printf("\n Function : playWithIfElseAgain");
	playWithIfElseAgain();

	// printf("\n Function : playWithTypes");
	// playWithTypes();

	printf("\n Function : playWithCharArray");
	playWithCharArray();

	printf("\n Function : playWithArray");
	playWithArray();

	printf("\n Function : playWithDoChange");
	playWithDoChange();

	printf("\n Function : playWithDoChangeAgain");
	playWithDoChangeAgain();

	// printf("\n Function : ");
	// printf("\n Function : ");
	// printf("\n Function : ");
	// printf("\n Function : ");
	// printf("\n Function : ");
	// printf("\n Function : ");	
	// printf("\n Function : ");
	// printf("\n Function : ");
	// printf("\n Function : ");
	// printf("\n Function : ");
	// printf("\n Function : ");
	// printf("\n Function : ");	
}