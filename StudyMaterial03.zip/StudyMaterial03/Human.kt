
package learnKotlin

// DESIGN PRINCIPLE
//		Design Toward Interfaces Rather Than Concrete Classes
//				Your Code Design Should Be Governed By Interfaces
//		Brings Contract In System
// WHAT To Do It!

interface Superpower {
	fun fly()
	fun saveWorld()
}

open class SpidermanOld {
	open fun fly() 		   { println("Fly Like Spiderman!") }
	open fun saveWorld()   { println("Save World Like Spiderman!") }
}

// Spiderman Explicitly Made Superpower
class Spiderman : Superpower {
	override fun fly() 		   { println("Fly Like Spiderman!") }
	override fun saveWorld()   { println("Save World Like Spiderman!") }
}

class Superman : Superpower  {
	override fun fly() 		   { println("Fly Like Superman!") }
	override fun saveWorld()   { println("Save World Like Superman!") }
}

class Heman : Superpower  {
	override fun fly() 		   { println("Fly Like Heman!") }
	override fun saveWorld()   { println("Save World Like Heman!") }
}

// class HumanDesign1 : Spiderman {
// 	fun fly() 		   { super.fly() }		// { println("Fly Like Human!") }
// 	fun saveWorld()    { super.saveWorld() }// { println("Save World Like Human!") }
// }

// class HumanDesign1 : Spiderman() {
class HumanDesign1 : SpidermanOld() {
	override fun fly() 		    { super.fly() }		// { println("Fly Like Human!") }
	override fun saveWorld()    { super.saveWorld() }// { println("Save World Like Human!") }
}

// SOLID PRINCIPLES
//		S : Single Responsibiilty Design
//		O : Open-Close Design
//			Classes Are Open For Extension But Close For Modification

// HumanDesign Polymorphic
// Composition Design Pattern
//		Composing Human With power Of Superpower
class HumanDesign2 {
	// Delegating The Power Flying and Saving World
	// Emdedding Object Of Superpower Type
	var power : Superpower? = null
	fun fly() 		  { power?.fly() 	  }// { println("Fly Like Human!") }
	fun saveWorld()   { power?.saveWorld() }// { println("Save World Like Human!") }
}


fun playWithHuman() {
	var human1 = HumanDesign1()
	human1.fly()
	human1.saveWorld()

	var human2 = HumanDesign2()
	human2.power = Spiderman() // Configuring Spiderman
	human2.fly()
	human2.saveWorld()

	// 
	human2.power = Superman() // Configuring Superman
	human2.fly()
	human2.saveWorld()

	human2.power = Heman()		// Configuring Heman
	human2.fly()
	human2.saveWorld()	
// }
}

fun main() {
	playWithHuman()
}