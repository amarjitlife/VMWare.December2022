
package main

import (
    "fmt"
    "math"
    "strings"
    "bytes"
    "strconv"
)

//___________________________________________________________

// Numeric types
// An integer, floating-point, or complex type represents the set of integer, 
// floating-point, or complex values, respectively. They are collectively 
// called numeric types. The predeclared architecture-independent numeric types are:

// uint8       the set of all unsigned  8-bit integers (0 to 255)
// uint16      the set of all unsigned 16-bit integers (0 to 65535)
// uint32      the set of all unsigned 32-bit integers (0 to 4294967295)
// uint64      the set of all unsigned 64-bit integers (0 to 18446744073709551615)

// int8        the set of all signed  8-bit integers (-128 to 127)
// int16       the set of all signed 16-bit integers (-32768 to 32767)
// int32       the set of all signed 32-bit integers (-2147483648 to 2147483647)
// int64       the set of all signed 64-bit integers 
//					(-9223372036854775808 to 9223372036854775807)

// float32     the set of all IEEE-754 32-bit floating-point numbers
// float64     the set of all IEEE-754 64-bit floating-point numbers

//		Default Type For 90.90 Value Will Be float64
// 		var something = 90.90

// complex64   the set of all complex numbers with float32 real and imaginary parts
// complex128  the set of all complex numbers with float64 real and imaginary parts

// byte        alias for uint8
// rune        alias for int32

//___________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// Plot Of Function Sin( R ) / R

const (
	width, height = 600, 320   
	cells = 100
	xyrange = 30.0
	xyscale = width / 2 / xyrange
	zscale = height * 0.4
	angle = math.Pi / 6
) 

var sin30, cos30 = math.Sin( angle ), math.Cos( angle )

// Function
//		Taking Two Arguments Of Type float64
//		Returning One Value Of Type float64

// Following Both Lines Are Equivalent
// func f(x float64, y float64) float64 {
func f(x, y float64) float64 {
	r := math.Hypot(x, y)
	return math.Sin(r) / r
}

// Function
//		Taking Two Arguments Of Type int
//		Returning One Tuple Of Type ( float64, float64 )
func corner(i, j int) ( float64, float64 ) {
	x := xyrange * ( float64( i ) / cells - 0.5 )
	y := xyrange * ( float64( j ) / cells - 0.5 )

	// Expression Is A Statement Having Return Value
	// Type Of z Will Be
	// 1. Type Infererencing From RHS
	//		From RHS Expression
	// 2. Type Binding With LHS
	//		Bind The Inferred Type With LHS
	// Both Type Inferrencing and Binding Happens At Compile Time
	z := f(x, y)
	
	sx := width/2  + ( x - y ) * cos30 * xyscale
	sy := height/2 + ( x + y ) * sin30 * xyscale - z * zscale

	return sx, sy  // Returning Tuple Of Tow Values
}

func playWithCanvas() {
	fmt.Printf("<svg xmlns='http://www.w3.org/2000/svg' "+
	"style='stroke: grey; fill: white; stroke-width: 0.7' "+
	"width='%d' height='%d'>", width, height)

	for i := 0 ; i < cells ; i++ {
		for j := 0 ; j < cells ; j++ {
			ax, ay := corner( i + 1 , j )
			bx, by := corner( i , j )
			cx, cy := corner( i , j + 1 )
			dx, dy := corner( i + 1 , j + 1 )

			fmt.Printf("<polygon points='%g,%g %g,%g %g,%g %g,%g'/>\n",
				ax, ay, bx, by, cx, cy, dx, dy)

		}
	}

	fmt.Println("</svg>")
}

//___________________________________________________________
//___________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// Complex Numbers 
// In Mathematics
//		Set Of = { a + bi : a and b belongs to R }

// In Go Language
// complex128
//		Set Of = { a + bi : a and b belongs to float64 }

// complex64
//		Set Of = { a + bi : a and b belongs to float32 }

func playWithComplexTypes() {

	var x complex128 = complex(1, 2) // 1 + 2i
	var y complex128 = complex(3, 4) // 3 + 4i

	fmt.Println( x )
	fmt.Println( y )

	fmt.Println( x + y )
	fmt.Println( x - y )
	fmt.Println( x * y )
	fmt.Println( real( y ) )
	fmt.Println( imag( y ) )

	fmt.Println( 1i * 1i )

	xx := 1 + 2i
	yy := 3 + 4i
	fmt.Println( xx )
	fmt.Println( yy )

	fmt.Println( xx + yy )
	fmt.Println( xx - yy )
	fmt.Println( xx * yy )
	fmt.Println( real( yy ) )
	fmt.Println( imag( yy ) )
}


//___________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func basename( s string ) string {
	for i := len( s ) - 1 ; i >= 0 ; i-- {
		if s[i] == '/' {
			s = s [ i + 1 : ] // Slicing
			break
		}
	}

	for i := len( s ) - 1 ; i >= 0 ; i-- {
		if s[i] == '.' {
			s = s [ : i ] // Slicing
			break
		}
	}
	return s
}

func basenameAgain( s string ) string {
	slash := strings.LastIndex( s, "/" )
	s = s[ slash + 1 : ]

	// Go Idiomatic Style
	if dot := strings.LastIndex( s, ".") ; dot >= 0 {
		s = s[ : dot ]
	}

	return s 
}

func playWithBaseName() {
	fmt.Println( basename( "media/WorkArea/Trainings.Running/VMWare/Progress") )
	fmt.Println( basename( "media/WorkArea/Trainings.Running/VMWare/Progress/GoTypes.go") )

	fmt.Println( basenameAgain( "media/WorkArea/Trainings.Running/VMWare/Progress") )
	fmt.Println( basenameAgain( "media/WorkArea/Trainings.Running/VMWare/Progress/GoTypes.go") )
}


//___________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func playWithStringsFunctions() {
    fmt.Println("Contains:  ", strings.Contains("test", "es"))
    fmt.Println("Count:     ", strings.Count("test", "t"))
    fmt.Println("HasPrefix: ", strings.HasPrefix("test", "te"))
    fmt.Println("HasSuffix: ", strings.HasSuffix("test", "st"))
    fmt.Println("Index:     ", strings.Index("test", "e"))
    fmt.Println("Join:      ", strings.Join([]string{"a", "b"}, "-"))
    fmt.Println("Repeat:    ", strings.Repeat("a", 5))
    fmt.Println("Replace:   ", strings.Replace("foo", "o", "0", -1))
    fmt.Println("Replace:   ", strings.Replace("foo", "o", "0", 1))
    fmt.Println("Split:     ", strings.Split("a-b-c-d-e", "-"))
    fmt.Println("ToLower:   ", strings.ToLower("TEST"))
    fmt.Println("ToUpper:   ", strings.ToUpper("test"))
}

//___________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// In C Language
	// There Is No String Type In C
	// String Value Denoted By ""
	// String Is Sequence Of ASCII Characters Stored In char Type Array
	// In C
	//		String Follows ASCII Coding
	//		String Ends With '\0' Null ASCII Character In Memory

// In Go Language
	// A string is an immutable sequence of bytes. 
	// Strings may contain arbitrary data, including bytes with value 0, 
	// but usually they contain human-readable text. 

	// Text strings are conventionally interpreted as UTF-8-encoded sequences 
	// of Unicode code points (runes)
	// It Stores Unicode Characters

	// Internal Structure Of string Type In Go Langauge

		// type _string struct {
		// 		elements *byte // underlying bytes
		// 		len      int   // number of bytes
		// }

// The built-in len function returns the number of bytes (not runes) in a string, 
// and the index operation s[i] retrieves the i-th byte of string s, where 0 ≤ i < len(s).

// The i-th byte of a string is not necessarily the i-th character of a string, 
// because the UTF-8 encoding of a non-ASCII code point requires two or more bytes.

func playWithStringType() {
	// s Will Be string Type
	//	string Are Unicode String
	s := "Hello, World!"

	fmt.Println( s )
	fmt.Println( "String Length : ", len( s ) )
	// Hello, World!
	// String Length :  13

	// 한 Can Be Represented With 
	//		Unicode Point \uD55C"
	//		Unicode Point \u1112\u1161\u11AB"
	s1 := "Hello, World!\uD55C"

	fmt.Println( s1 )
	fmt.Println( "String Length : ", len( s1 ) )
	// Hello, World!한
	// String Length :  16

	s2 := "Hello, World!\u1112\u1161\u11AB"
	fmt.Println( s2 )
	fmt.Println( "String Length : ", len( s2 ) )
	// Hello, World!한
	// String Length :  22

	fmt.Println( "\u1112")
	fmt.Println( "\u1161")
	fmt.Println( "\u11AB")
	// ᄒ  ᅡ    ᆫ

	fmt.Println( s[0], s[7] )
	fmt.Println( s[ 0 : 5 ] )
	fmt.Println( s[ : 5 ] )
	fmt.Println( s[ 7 :  ] )
	fmt.Println( s[  :  ] )

	fmt.Println( "Goodbye " + s[ 5 :  ] )

	ss := "Left Foot"
	tt := ss
	fmt.Println( tt )
	ss += ", and Right Foot"
	fmt.Println( ss )
}

//___________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func insertCommas( s string ) string {
	n := len( s )

	if n <= 3 { return s }
	return insertCommas( s[ : n - 3] ) + "," + s[ n -3 : ]
}

func playWithInsertCommas() {
	fmt.Println( insertCommas( "12345678" ) )
	fmt.Println( insertCommas( "999" ) )
	fmt.Println( insertCommas( "6789999" ) )
	fmt.Println( insertCommas( "89389438493849384398439483" ) )
	fmt.Println( insertCommas( "123456788888888888" ) )
}

//___________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func intsToString( values []int ) string {
	var buffer bytes.Buffer

	buffer.WriteByte( '[' )

	// values = []int{ 10, 20, 30, 40 } 
	// range values = [ (0, 10), (1, 20), (2, 30),  (3, 40) ]
	//		Tuples Are Getting Unpacked On Index and Value
	for index, value := range values {
		fmt.Printf("\nAt Index: %d Value: %v", index, value)

		if index > 0 {
			buffer.WriteString( ", " )
		}
		fmt.Fprintf( &buffer, "%d", value )
	}

	buffer.WriteByte( ']' )
	return buffer.String()
}

func playWithIntsToString() {
	fmt.Println("\nString : ", intsToString( []int{ 10, 20, 30, 40 } ) )

	fmt.Println("\nString : ", intsToString( []int{ 10, 20, 30, 40, 900, 999, 1000, 99980 } ) )
	fmt.Println("\nString : ", intsToString( []int{ 1000, 2000, 3000, 40000, 800000 } ) )
}

//___________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func playWitStringUnicode() {
	const something = `⌘`

	fmt.Printf("Plain String: ")
	fmt.Printf("%s", something )
	fmt.Println()

	fmt.Printf("Quoted String: ")
	fmt.Printf("%q", something )
	fmt.Println()


	fmt.Printf("Hex Bytes: ")
	for i := 0 ; i < len( something ) ; i++ {
		fmt.Printf(" %x ", something[i] )
	}

	fmt.Println()	

	somethingAgain := "Hello, 한瘔"
	fmt.Println( somethingAgain )
	fmt.Println( len( somethingAgain ) )
	fmt.Printf("Hex Bytes: ")
	for i := 0 ; i < len( somethingAgain ) ; i++ {
		fmt.Printf(" %x ", somethingAgain[i] )
	}

	fmt.Println()	

	for index, character := range somethingAgain {
		fmt.Printf("\n%d\t %q \t %x", index, character, character)
	}

	characterCount := 0
	for _, _ = range somethingAgain {
		characterCount++
	}

	fmt.Println("\nUnicode Character Count : ", characterCount	)	

	characterCount = 0
	for range somethingAgain {
		characterCount++
	}

	fmt.Println("\nUnicode Character Count : ", characterCount	)

	x := 123

	// y Is string Type
	y := fmt.Sprintf( "%d", x )
	fmt.Println( y )

	fmt.Println( strconv.Itoa( x ) )
	fmt.Println( strconv.Atoi( "8970" ) )
}

//___________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func playWithConstants() {

	const (
		a = 1
		b
		c = 2
		d 
	)

	fmt.Println( a )
	fmt.Println( b )
	fmt.Println( c )
	fmt.Println( d )
	// 1
	// 1
	// 2
	// 2

	const (
		aa = 1
		bb = 2
		cc = 3
		dd = 4
		xx = 3
		// dd = 16
	)

	fmt.Println( aa )
	fmt.Println( bb )
	fmt.Println( cc )
	fmt.Println( dd )
	fmt.Println( xx )

	// Constant Generator iota
	const (
		aaa = iota // 0
		bbb = iota // 1
		ccc = iota // 2
		ddd = iota // 3
	)

	fmt.Println( aaa )
	fmt.Println( bbb )
	fmt.Println( ccc )
	fmt.Println( ddd )

	const (
		a1 = 1 << iota // a1 = 1 ( iota = 0 ) 1 << 0 = 2^0
		b1 = 1 << iota // b1 = 2 ( iota = 1 ) 1 << 1 = 2^1
		c1 = 1 << iota // c1 = 4 ( iota = 2 ) 1 << 2 = 2^2
		d1 = 1 << iota // d1 = 8 ( iota = 3 ) 1 << 3 = 2^3
	)

	fmt.Println( a1 )
	fmt.Println( b1 )
	fmt.Println( c1 )
	fmt.Println( d1 )

	const (
		a2 = 1 << iota // a1 = 1 ( iota = 0 ) 1 << 0 = 2^0
		b2 = 1 << iota // b1 = 2 ( iota = 1 ) 1 << 1 = 2^1
		c2 = 1 << iota // c1 = 4 ( iota = 2 ) 1 << 2 = 2^2
		x2 = 3         //        ( iota = 3 ) Unused iota Value
		d2 = 1 << iota // d1 = 8 ( iota = 4 ) 1 << 4 = 2^4
	)

	fmt.Println( a2 )
	fmt.Println( b2 )
	fmt.Println( c2 )
	fmt.Println( x2 )
	fmt.Println( d2 )

	const (
		u 			= iota * 42
		v float64 	= iota * 42
		w 			= iota * 42
	)

	fmt.Println( u )
	fmt.Println( v )
	fmt.Println( w )

	const x = iota
	const y = iota
	fmt.Println( x )
	fmt.Println( y )


	const (
		a3 = 1 	// iota // 0
		b3 		// iota // 1
		c3 = iota // 2
		d3 = iota // 3
	)
	// 1
	// 1
	// 2
	// 3

	fmt.Println( a3 )
	fmt.Println( b3 )
	fmt.Println( c3 )
	fmt.Println( d3 )

	type Weekday int 

	const (
		Sunday Weekday = iota
		Monday
		Tuesday
		Wednesday
		Thrusday
		Friday
		Saturday
	)

	fmt.Println( Sunday )
	fmt.Println( Monday )
	fmt.Println( Tuesday )
	fmt.Println( Thrusday )
	fmt.Println( Friday )
	fmt.Println( Saturday )

	// Following Code And Above Are Same
	// const (
	// 	Sunday Weekday 	= iota
	// 	Monday 			= iota
	// 	Tuesday 		= iota
	// 	Wednesday 		= iota
	// 	Thrusday 		= iota
	// 	Friday			= iota
	// 	Saturday		= iota
	// )

	const (
	    _ = 1 << (10 * iota)  	// 10 Raised To Power 0
	    KiB // 1024  		 	// 10 Raised To Power 1 i.e. 2^10
	    MiB // 1048576
	    GiB // 1073741824
	    TiB // 1099511627776
	    PiB // 1125899906842624
	    EiB // 1152921504606846976
	    ZiB // 1180591620717411303424
	    YiB // 1208925819614629174706176
	)

	fmt.Println( KiB )
	fmt.Println( MiB )
	fmt.Println( GiB )
	fmt.Println( TiB )
	fmt.Println( PiB )
	fmt.Println( EiB )

	// cannot use ZiB (untyped int constant 1180591620717411303424) as 
	// int value in argument to fmt.Println (overflows)

	// fmt.Println( ZiB )
	// fmt.Println( YiB )
}

//___________________________________________________________

func playWithDefaultInitialValues() {
	var a int
	var i8 int8
	var ui8 uint8

	var f1 float32
	var f2 float64

	var s string

	var c1 complex64 
	var c2 complex128

	var b bool

	fmt.Printf("%d %d %d\n", a, i8, ui8)
	fmt.Printf("%f %f\n", f1, f2)	
	fmt.Printf("%s \n", s)	
	fmt.Printf("%v %v", c1, c2)	
	fmt.Printf("%t \n", b)	
}

// Function : playWithDefaultInitialValues
// 0 0 0
// 0.000000 0.000000
 
// (0+0i) (0+0i)false 
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________

func main() {
	// fmt.Println("\nFunction : playWithCanvas")
	// playWithCanvas()

	fmt.Println("\nFunction : playWithComplexTypes")
	playWithComplexTypes()

	fmt.Println("\nFunction : playWithBaseName")
	playWithBaseName()

	fmt.Println("\nFunction : playWithStringsFunctions")
	playWithStringsFunctions()

	fmt.Println("\nFunction : playWithStringType")
	playWithStringType()

	fmt.Println("\nFunction : playWithInsertCommas")
	playWithInsertCommas()

	fmt.Println("\nFunction : playWithIntsToString")
	playWithIntsToString()

	fmt.Println("\nFunction : playWitStringUnicode")
	playWitStringUnicode()

	fmt.Println("\nFunction : playWithConstants")
	playWithConstants()

	fmt.Println("\nFunction : playWithDefaultInitialValues")
	playWithDefaultInitialValues()

	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
}

