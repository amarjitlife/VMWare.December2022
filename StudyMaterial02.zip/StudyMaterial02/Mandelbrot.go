
package main

import (
	"image"
	"image/color"
	"image/png"
	"math/cmplx"
	"os"
)

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// The Mandelbrot set (/ˈmændəlbroʊt, -brɒt/)[1][2] is the set of 
// complex numbers {\displaystyle c}c for which the function 
// f(z)=z^2+c does not diverge to infinity when iterated from 
// z=0

func mandelbrot( z complex128 ) color.Color {
	const iterations = 200
	const contrast = 15

	var v complex128

	// Why We Are Doing Explicit Type Casting???

	// uint8() Used For Explicit Type Casting	
	// for n := 0 ; n < iterations ; n++ {
	for n := uint8( 0 ) ; n < iterations ; n++ {
		v = v * v + z

		if cmplx.Abs( v ) > 2 {
			return color.Gray{ 255 - contrast * n }
		}	
	}

	return color.Black
}

func playWithMandelbrot() {
	const (
		xmin, ymin, xmax, ymax 	= -2, -2, +2, +2
		width, height 			= 1024, 1024
	)

	img := image.NewRGBA( image.Rect( 0, 0, width, height) )

	for py := 0 ; py < height ; py++ {
		
		y := float64( py ) / height * (ymax - ymin) + ymin

		for px := 0; px < width; px++ {

			x := float64( px ) / width * (xmax-xmin) + xmin
			
			z := complex(x, y)

			// Image point (px, py) represents complex value z.
			img.Set(px, py, mandelbrot(z))
		}
	}
	png.Encode( os.Stdout, img) // NOTE: ignoring errors
}

//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________

func main() {
	playWithMandelbrot()
}

