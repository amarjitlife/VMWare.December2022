
package main

import (
	"fmt"
	"math"
	"image/color"
	"bytes"
)

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

type Point struct {
	X, Y float64
}

func Distance( p Point, q Point ) float64 {
	return math.Hypot( q.X - p.X, q.Y - p.Y )
}

// In Go Method i.e. Member Function Of Type/Structure Point 
// 		Will Be Looking As Follows
// 		Method : Functions Binded With Reciever Type
// 		Receiver Type : Point
func (p Point) Distance( q Point ) float64 {
	return math.Hypot( q.X - p.X, q.Y - p.Y )
}

// In C++ Method i.e. Member Function Of Type/Class Point 
// 		Will Be Looking As Follows
// float64 Point::Distance( Point q) {
// 	return math.Hypot( q.X - p.X, q.Y - p.Y )
// }

type Path []Point

// In Go Method i.e. Member Function Of Type/Structure Point 
// 		Will Be Looking As Follows
// 		Method : Functions Binded With Reciever Type
// 		Receiver Type : Path
func (path Path) Distance() float64 {
	sum := 0.0
	// Calculate Total Distance Of Path Traversed
	for i := range path {
		if i > 0 {
				   // Sending Distance Message To Point	
			sum += path[ i-1 ].Distance( path[i] )
		}
	}

	return sum
}

// func (f float64) doSomething( g float64 ) float64 {
// 	return f + g
// }

func playWithFunctionsAndMethods() {
	var point1 = Point { 10.0, 20.0 }
	var point2 = Point { 100.0, 200.0 }

											// Calling Distance Function
	fmt.Println("Distance Using Function: ", Distance( point1, point2 ) )
											// Sending Distance Message To Object point1
	fmt.Println("Distance Using Method  : ", point1.Distance( point2 ) )

	var path Path = Path {
		Point{ 10, 10 },
		Point{ 20, 20 },
		Point{ 30, 30 },
	}

							// Sending Distance Message To Object path
	fmt.Println("Path Traversed: ", path.Distance() )

//  cannot define new methods on non-local type float64
// 	some := 90.90
// 	result := some.doSomething( 100.100 )
}


//__________________________________________________________________

type ColoredPoint struct {
	Point
	Color color.RGBA
}

// Reciever Type Is Reference To Point Type
func (p *Point) ScaleBy( factor float64 ) {
	p.X = p.X * factor
	p.Y = p.Y * factor
}

func playWithColoredPointMethods() {
	red  := color.RGBA{ 255, 0, 0, 255 }
	blue := color.RGBA{ 0, 255, 0, 255 }

	var point1 = ColoredPoint{ Point{ 10, 20 }, red }
	var point2 = ColoredPoint{ Point{ 1,  2  }, blue }

	fmt.Println("Point1 : ", point1 )
	fmt.Println("Point2 : ", point2 )
	fmt.Println("Point Distance :", point1.Distance( point2.Point ) )

	point1.ScaleBy( 2 )
	point2.ScaleBy( 5 )

	fmt.Println("Point1 : ", point1 )
	fmt.Println("Point2 : ", point2 )

	fmt.Println("Point Distance :", point1.Distance( point2.Point ) )
}

// We can call methods of the embedded Point field using a receiver of 
// type ColoredPoint, even though ColoredPoint has no declared methods

// Function : playWithColoredPointMethods
// Point1 :  {{10 20} {255 0 0 255}}
// Point2 :  {{1 2} {0 255 0 255}}
// Point1 :  {{10 20} {255 0 0 255}}
// Point2 :  {{1 2} {0 255 0 255}}

// Function : playWithColoredPointMethods
// Point1 :  {{10 20} {255 0 0 255}}
// Point2 :  {{1 2} {0 255 0 255}}
// Point1 :  {{20 40} {255 0 0 255}}
// Point2 :  {{5 10} {0 255 0 255}}

//___________________________________________________________________
// HOME WORK
// HOME WORK
// HOME WORK

// An IntSet is a set of small non-negative integers.
// 		Its zero value represents the empty set.
type IntSet struct {
	words []uint64
}

// Has reports whether the set contains the non-negative value x.
func (s *IntSet) Has(x int) bool {
	word, bit := x/64, uint(x%64)
	return word < len(s.words) && s.words[word]&(1<<bit) != 0
}

// Add adds the non-negative value x to the set.
func (s *IntSet) Add(x int) {
	word, bit := x/64, uint(x%64)
	for word >= len(s.words) {
		s.words = append(s.words, 0)
	}
	s.words[word] |= 1 << bit
}

// UnionWith sets s to the union of s and t.
func (s *IntSet) UnionWith(t *IntSet) {
	for i, tword := range t.words {
		if i < len(s.words) {
			s.words[i] |= tword
		} else {
			s.words = append(s.words, tword)
		}
	}
}

// String returns the set as a string of the form "{1 2 3}".
func (s *IntSet) String() string {
	var buf bytes.Buffer
	buf.WriteByte('{')
	for i, word := range s.words {
		if word == 0 {
			continue
		}
		for j := 0; j < 64; j++ {
			if word&(1<<uint(j)) != 0 {
				if buf.Len() > len("{") {
					buf.WriteByte(' ')
				}
				fmt.Fprintf(&buf, "%d", 64*i+j)
			}
		}
	}
	buf.WriteByte('}')
	return buf.String()
}

func playWithIntSet() {
	var x, y IntSet
	x.Add(1)
	x.Add(144)
	x.Add(9)
	fmt.Println(x.String()) // "{1 9 144}"

	y.Add(9)
	y.Add(42)
	fmt.Println(y.String()) // "{9 42}"

	x.UnionWith(&y)
	fmt.Println(x.String()) // "{1 9 42 144}"

	fmt.Println(x.Has(9), x.Has(123)) // "true false"

	// Output:
	// {1 9 144}
	// {9 42}
	// {1 9 42 144}
	// true false
}

func playWithIntSetAgain() {
	var x IntSet
	x.Add(1)
	x.Add(144)
	x.Add(9)
	x.Add(42)

	fmt.Println( &x )         // "{1 9 42 144}"
	fmt.Println( x.String() ) // "{1 9 42 144}"
	fmt.Println(x)          // "{[4398046511618 0 65536]}"

	// Output:
	// {1 9 42 144}
	// {1 9 42 144}
	// {[4398046511618 0 65536]}
}

//__________________________________________________________________
//__________________________________________________________________
//__________________________________________________________________
//__________________________________________________________________
//__________________________________________________________________
//__________________________________________________________________
//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func main() {
	fmt.Println("\nFunction : playWithFunctionsAndMethods")
	playWithFunctionsAndMethods()

	fmt.Println("\nFunction : playWithColoredPointMethods")
	playWithColoredPointMethods()

	fmt.Println("\nFunction : playWithIntSet")
	playWithIntSet()
	
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
}

