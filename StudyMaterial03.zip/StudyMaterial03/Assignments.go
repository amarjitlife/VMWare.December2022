______________________________________________________________

DAY 01
______________________________________________________________

	ASSSIGNMENT 01: READING AND REASONING ASSIGNMENT
		Chapter 05 : Pointers and Arrays [ MUST MUST ]
		Chapter 02 : Types, Operators and Expressions [ MUST ]
		
			The C Programming Language 2nd Edition 
				By Brian Kernigham and Dennis Ritchie

______________________________________________________________

DAY 02
______________________________________________________________

	ASSSIGNMENT A01: THINKING, EXPLORATION REASONING ASSIGNMENT
		1. How Floating Points Are Stored in C/C++/Java/Python and Go
		2. How Divide By Zero Dealt in C/C++/Java/Python and Go
		3. How Infinity Are Treated In C/C++/Java/Python and Go
		4. How NaN Are Treated In C/C++/Java/Python and Go

	        System.out.println(1.0 / 0.0); 
	        System.out.println(-1.0 / 0.0);
	        System.out.println(0.0 / 0.0);
	        
	        System.out.println(1.0 / 0.0 == Double.POSITIVE_INFINITY);
	        System.out.println(-1.0 / 0.0 == Double.NEGATIVE_INFINITY);

	        System.out.println(0.0 / 0.0 == Double.NaN);

	        System.out.println(2.0 - 1.1);        

	ASSSIGNMENT A02: EXPERIMENT AND EXPLORE GO CODE
		Experiment and Explore Go Code Till Now Done!

______________________________________________________________

DAY 03
______________________________________________________________

	ASSSIGNMENT A01: THINKING, EXPLORATION REASONING ASSIGNMENT
		Create 2 Dimentional Jagged Array In C Using Pointers
	

	