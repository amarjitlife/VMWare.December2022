
package main

import (
    "fmt"
    // "strings"
)

//___________________________________________________________

// Composite Types, the molecules created by combining the basic types 
// in various ways. We’ll talk about
// four such types
// 	arrays, structs, slices, maps

// Arrays and structs are aggregate types; 
// 		Their values are concatenations of other values in memory. 
//		Arrays are homogeneous—their elements all have the same type—
//		whereas structs are heterogeneous. 

//	Both arrays and structs are fixed size. 
//	In contrast, slices and maps are dynamic data structures that 
//		grow as values are added.

//___________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func playWithArrays() {
	
	// Creating Array Of 3 Members
	//		Index Starts From 0 To len - 1 i.e. [0, len)
	//		All Elements Of Array Initialised To Zeros Of Type

	var a [3]int

	for index, value := range a {
		fmt.Printf("\nAt Index: %d Value: %v", index, value)
	}

	fmt.Println()

	fmt.Println( a[0] )
	fmt.Println( a[1] )
	fmt.Println( a[2])
	fmt.Println( a[ len( a ) - 1])

	// invalid argument: array index 3 out of bounds [0:3]
	// fmt.Println( a[ len( a ) ] )

	for _, value := range a {
		fmt.Printf("\nValue: %v", value)
	}

	var q [5]int = [5]int{ 10, 20, 30, 40, 50 }
	var r [5]int = [5]int{ 10, 20, 30 }

	fmt.Println("Array Length : ", len(q) )
	for index, value := range q {
		fmt.Printf("At index: %d value: %d\n", index, value)
	}

	fmt.Println("Array Length : ", len(r) )
	for index, value := range r {
		fmt.Printf("At index: %d value: %d\n", index, value)
	}

	// var qq [5]int = { 10, 20, 30, 40, 50 }
	// var rr [5]int = { 10, 20, 30 }

	var q1 = [5]int{ 10, 20, 30, 40, 50 }
	var r1 = [5]int{ 10, 20, 30 }

	for index, value := range q1 {
		fmt.Printf("At index: %d value: %d\n", index, value)
	}

	fmt.Println("Array Length : ", len(r) )
	for index, value := range r1 {
		fmt.Printf("At index: %d value: %d\n", index, value)
	}

	// [...] Means Compiler Will Deduce Array Size From Initialisation List
	// s Type Will Be [4]int
	s := [...]int{ 10, 20, 100, 111 }
	fmt.Println("Array Length : ", len(s) )
	fmt.Printf( "Data Type : %T \n", s )

	for index, value := range s {
		fmt.Printf("At index: %d value: %d\n", index, value)		
	}

	some := [3]int { 100, 200, 300 }
	fmt.Printf( "Data Type : %T \n", some )

	someAgain := [...]int{ 99 : -1  }
	// for index, value := range someAgain {
	// 	fmt.Printf("At index: %d value: %d\n", index, value)
	// }

	fmt.Println("Array Length : ", len( someAgain ) )
	fmt.Printf( "Data Type : %T \n", someAgain )

	aa := [2]int{ 10, 20 }
	bb := [...]int{ 10, 20 }
	cc := [2]int{ 10, 30 }
	ff := [2]float32 { 10.0, 20.0 }

	fmt.Println( aa == bb, aa == cc, bb == cc )
	// true false false

	// invalid operation: aa == ff (mismatched types [2]int and [2]float32)
	// fmt.Println( aa == ff )
	fmt.Println( ff )

	dd := [3]int{ 10, 30 }
	fmt.Println( dd )

	// invalid operation: aa == dd (mismatched types [2]int and [3]int)
	// fmt.Println( aa == dd )
}


//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

type Flags uint

const ( // STATUS BITs ARE DEFINED AS FOLLOWS
    FlagUp Flags = 1 << iota // is up
	FlagBroadcast		 	 // supports broadcast access capability
	FlagLoopback             // is a loopback interface
	FlagPointToPoint         // belongs to a point-to-point link
	FlagMulticast            // supports multicast access capability
)

func IsUp(v Flags) bool     { return v & FlagUp == FlagUp } // & (bitwise AND)
func TurnDown(v *Flags)     { *v &^= FlagUp }   // &^ (AND NOT): 
												// This is a bit clear operator.
func SetBroadcast(v *Flags) { *v |= FlagBroadcast } // | (bitwise OR)
func IsCast(v Flags) bool   { return v & (FlagBroadcast | FlagMulticast) != 0 }

func playWithFlags() {
	var v Flags = FlagMulticast | FlagUp
	fmt.Printf("%b %t\n", v, IsUp(v)) // "10001 true"
	
	// Passing Reference Of v
	TurnDown( &v )
	fmt.Printf("%b %t\n", v, IsUp(v)) // "10000 false"
	
	// Passing Reference Of v
	SetBroadcast( &v )
	fmt.Printf("%b %t\n", v, IsUp(v))   // "10010 false"
	fmt.Printf("%b %t\n", v, IsCast(v)) // "10010 true"
}

//___________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func doChangeAgain1( a [10]int ) {
	for i, _ := range a {
		a[i] = 100
	}
}

// Following Function Takes Argument:
//		Passing Array Reference
func doChangeAgain2( a *[10]int ) {
	for i, _ := range a {
		a[i] = 100
	}
}

// Following Function Takes Argument:
//		Passing Array Slice
// Slices Are Pass By Reference
func doChangeAgain3( slice []int ) {
	for i, _ := range slice {
		slice[i] = 111
	}
}

func printArray( a [10]int ) {
	fmt.Println()
	for i, _ := range a {
		fmt.Printf("  %d  ", a[i])
	}	
}

// In Go 		- Arrays Are Pass By Value By Default
// In C/C++/Java- Arrays Are Pass By Reference By Default
func playWithDoChangeAgain() {
	var array [10]int = [10]int { 10, 20, 30, 40, 50 }

	fmt.Println("\nArrays Passed By Value...")
	printArray( array )
	doChangeAgain1( array )
	printArray( array )

	var array1 [10]int = [10]int { 10, 20, 30, 40, 50 }
	fmt.Println("\nArrays Passed By Reference...")
//	Passing Array Reference
	printArray( array1 )
	doChangeAgain2( &array1 )
	printArray( array1 )

	var array2 [10]int = [10]int { 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 }
	fmt.Println("\nArrays Passed By Slice...")
// 	Slices Are Pass By Reference
//		Passing Array Slice Refering All Elements
	printArray( array2 )
	doChangeAgain3( array2[ : ] )
	printArray( array2 )

	array2 = [10]int { 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 }
	fmt.Println("\nArrays Passed By Slice...")
// 	Slices Are Pass By Reference
//		Passing Array Slice Refering All Elements
	printArray( array2 )
	doChangeAgain3( array2[ : 4 ] )
	printArray( array2 )

	array2 = [10]int { 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 }
	fmt.Println("\nArrays Passed By Slice...")
// 	Slices Are Pass By Reference
//		Passing Array Slice Refering All Elements
	printArray( array2 )
	doChangeAgain3( array2[ 6 :  ] )
	printArray( array2 )

	array2 = [10]int { 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 }
	fmt.Println("\nArrays Passed By Slice...")
// 	Slices Are Pass By Reference
//		Passing Array Slice Refering All Elements
	printArray( array2 )
	doChangeAgain3( array2[ 3 : 7 ] )
	printArray( array2 )
}

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func playWithSlices() {
	months := [...]string{ 0 : "", "Jan", "Feb", "Mar", "Apr", "May",
					"Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" }

	fmt.Println("Months : ", months)

	quater1 := months[ 1 : 4 ]
	quater2 := months[ 4 : 7 ]
	summer  := months[ 2 : 7 ]

	fmt.Println("Quater1 :", quater1)
	fmt.Println("Quater2 :", quater2)
	fmt.Println("Summer  :", summer)

	for _, s := range summer {
		for _, q := range quater2 {
			if s == q {
				fmt.Printf(" %s Appears In Both \n", s)
			}
		}
	}

	// invalid operation: quater1 == quater2 (slice can only be compared to nil)
	// fmt.Println( quater1 == quater2, summer == quater2 )

	// String Values Are Immutable
	greeting := "Good Evening! Good"

	first 	:= greeting[ 1 : 4 ]
	last  	:= greeting[ 5 :   ]
	between := greeting[ 2 : 6 ]

	fmt.Println( greeting )
	fmt.Println( first )
	fmt.Println( last )
	fmt.Println( between )

	fmt.Println( first == last, first == between )

	firstGood := greeting[ : 4 ]
	lastGood  := greeting[ len(greeting) - 4 :  ]
	
	fmt.Println( firstGood, lastGood, len( firstGood ), len( lastGood ) )
	fmt.Println( firstGood == lastGood )

	// cannot assign to greeting[0] (value of type byte)
	// greeting[0] = "#"
}



//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________

func main() {
	fmt.Println("\nFunction : playWithArrays")
	playWithArrays()

	fmt.Println("\nFunction : playWithFlags")
	playWithFlags()

	fmt.Println("\nFunction : playWithDoChangeAgain")
	playWithDoChangeAgain()

	fmt.Println("\nFunction : playWithSlices")
	playWithSlices()

	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
}

