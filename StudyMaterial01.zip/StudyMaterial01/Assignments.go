______________________________________________________________

DAY 01
______________________________________________________________

	ASSSIGNMENT 01: READING AND REASONING ASSIGNMENT
		Chapter 05 : Pointers and Arrays [ MUST MUST ]
		Chapter 02 : Types, Operators and Expressions [ MUST ]
			The C Programming Language 2nd Edition 
				By Brian Kernigham and Dennis Ritchie

______________________________________________________________

DAY 02
______________________________________________________________



______________________________________________________________

DAY 03
______________________________________________________________


