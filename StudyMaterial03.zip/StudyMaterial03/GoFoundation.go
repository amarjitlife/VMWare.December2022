package main

// import "fmt"
// import "os"
// import "flag"
// import "strings"
// import "time"

import (
    "fmt"
    "os"
    "flag"
    "strings"
    "time"
)

//___________________________________________________________
//___________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// Function Which Takes No Argument And Doesn't Return Anything
func helloWorld() {
	fmt.Println("Hello, 世界")
}

//___________________________________________________________
//___________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

const boilingPointF = 212.0

// Farenhite To Centrigrate Function
// Function Which Takes One Argument And Return One Value
//	 	Argument and Return Type is float64
func fToC( f float64 ) float64 {
	return ( f - 32 ) * 5 / 9
}

func playWithConstantValriables() {
	var f = boilingPointF
	var c = ( f - 32 ) * 5 / 9

	fmt.Printf("Boiling Point: %g, Farenthiet To Centrigrade: %g\n", f, c)
	const freezingF, boilingF = 32.0, 212.0 // Local To Function


	fmt.Printf("%g Farenhiet Or %g Centrigrade", freezingF, fToC( freezingF ))
	fmt.Printf("%g Farenhiet Or %g Centrigrade", boilingF, fToC( boilingF ))
}

//___________________________________________________________
//___________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func playWithDataTypes() {
	// Annotating Variables Explicitly With Type

	// In C/C++
	//		Initialisation Is Programmer Job
	//		Default Will Be Garbage For Local Variable

	// In Go
	//		Initialisation Is Programmer Job
	//		Default Will Be Zero's Of Type
	var c, python, java bool
	var i int

	// Zero Of Type Will Be Default Values
	// false false false 
	// 0

	var ii, jj int = 10, 20

	// 1. Type Infererencing From RHS
	//		From RHS Expression
	// 2. Type Binding With LHS
	//		Bind The Inferred Type With LHS
	// Both Type Inferrencing and Binding Happens At Compile Time
	var iii, jjj = 10, 20

	// var iii, jjj

	/// Design Principle
	//		Expressiveness

	// Short Cut Notation
	// 		Similer To Python Style
	k := 3
	some, some1, something := true, false, "Good!"

	fmt.Println(c, python, java, i)
	fmt.Println( ii, jj )
	fmt.Println( iii, jjj )

	fmt.Println( k, some, some1, something )

	// 10 20
	// 10 20
	// 3 true false Good!
}

//___________________________________________________________
//___________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// Design Principle
//		Type Safety
//		Strict Type System

// Type Safety Code

// Celsius And Fahrenheit Are Type Aliases Of float64
// 		Type Aliases Can Be Used Wherever float64 Used
//		Creating It To Express Domain Knolegedge
//		To Improve Code Readibility

// Naming Conventions For Identifiers
//		Generally Identifiers Follows Camel Cases With First Word In Small

//		Identifiers First Alphabet Is Small
//			These Are Locals/Private To Pacakage
//		Identifiers First Alphabet Is Capital
//			These Are Exported From Pacakage

// Domain Knowledge
type Celsius  	float64
type Fahrenheit float64

func FToC( f Fahrenheit ) Celsius {	return Celsius( ( f - 32 ) * 5 / 9 )	}
func CToF( c Celsius ) Fahrenheit { return Fahrenheit( ( c * 9 / 5 + 32 ) ) }

const (
	BoilingC  		Celsius = 100.0
	FreezingC  		Celsius = 0
	AbsoluteZeroC  	Celsius = -273.15
	FreezingF  		Fahrenheit = 0.0
)

func playWithConstants() {
	// ./GoFoundation.go:127:6: someTemperature declared but not used
	// var someTemperature float64 = 80.80
	boilingF := CToF( BoilingC )

	fmt.Printf("\n %g", boilingF - CToF( FreezingC ) )	
	fmt.Printf("\n %g", boilingF )

	fmt.Printf("\n %g", BoilingC + FreezingC )


	// invalid operation: BoilingC + FreezingF (mismatched types Celsius and Fahrenheit)
	// fmt.Printf("\n %g", BoilingC + FreezingF )

	// invalid operation: BoilingC + someTemperature (mismatched types Celsius and float64)
	// fmt.Printf("\n %g", BoilingC + someTemperature )
}

//___________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func playWithForLoop( args []string ) {
	var s, sep string

	fmt.Printf("Command Line Arguments Count: %d" , len( args ) )

	sep = "\n"
	for i := 0 ; i < len( args ) ; i++ {
		s += sep + args[i]
	}

	fmt.Println( s )
}

//___________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func playWithFlagPackage() {
	var n = flag.Bool("n", false, "Omit Trailing New Line...")
	var sep = flag.String("s", " ", "String Seperator...")

	flag.Parse()
	fmt.Print( strings.Join( flag.Args(), *sep ) )

	if !*n {
		fmt.Println()
	}
}

//___________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func playWithFormatSpecifiers() {
	c := FToC(212.0)

	fmt.Println(c)

	fmt.Printf("\n %v", c)
	fmt.Printf("\n %f", c)
	fmt.Printf("\n %g", c)
	fmt.Printf("\n %e", c)
}


// General:
// %v	the value in a default format
// 			when printing structs, the plus flag (%+v) adds field names
// %#v	a Go-syntax representation of the value
// %T	a Go-syntax representation of the type of the value
// %%	a literal percent sign; consumes no value

// Boolean:

// %t	the word true or false
// Integer:

// %b	base 2
// %c	the character represented by the corresponding Unicode code point
// %d	base 10
// %o	base 8
// %O	base 8 with 0o prefix
// %q	a single-quoted character literal safely escaped with Go syntax.
// %x	base 16, with lower-case letters for a-f
// %X	base 16, with upper-case letters for A-F
// %U	Unicode format: U+1234; same as "U+%04X"

// Floating-point and complex constituents:

// %b	decimalless scientific notation with exponent a power of two,
// 	in the manner of strconv.FormatFloat with the 'b' format,
// 	e.g. -123456p-78
// %e	scientific notation, e.g. -1.234456e+78
// %E	scientific notation, e.g. -1.234456E+78
// %f	decimal point but no exponent, e.g. 123.456
// %F	synonym for %f
// %g	%e for large exponents, %f otherwise. Precision is discussed below.
// %G	%E for large exponents, %F otherwise
// %x	hexadecimal notation (with decimal power of two exponent), e.g. -0x1.23abcp+20
// %X	upper-case hexadecimal notation, e.g. -0X1.23ABCP+20
// String and slice of bytes (treated equivalently with these verbs):

// %s	the uninterpreted bytes of the string or slice
// %q	a double-quoted string safely escaped with Go syntax
// %x	base 16, lower-case, two characters per byte
// %X	base 16, upper-case, two characters per byte
// Slice:

// %p	address of 0th element in base 16 notation, with leading 0x
// Pointer:

// %p	base 16 notation, with leading 0x
// The %b, %d, %o, %x and %X verbs also work with pointers,
// formatting the value exactly as if it were an integer.


// REFERENCE LINK : https://pkg.go.dev/fmt

//___________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// DESIGN PRINCIPLE
//		Repect Type Definition
//		Type Conversions Must Be Done Explicitly
//		Segregate Type Conversion Logic To Special Functions
//			And Reason Them Well.

func playWithIfElse() {
	x := -10
	// Conversion Happening
	//		1. Type Conversion Happens
	//		2. Value Conversion
	// ./GoFoundation.go:247:5: non-boolean condition in if statement
	// if ( x ) {
	// if  x  {
	if x == -10 {
		fmt.Println("Oye Hoye!!!")
	} else {
		fmt.Println("Wah Wah!!!")
	}
}

func btoi( b bool ) int {
	if b { return 1 }
	return 0
}

func itob(i int) bool { return i != 0 }

func playWithIfElseAgain() {
	x := -10
	// In Go Language Bool Type  To Int Type Conversion Not Possible
	// Compilation Error : non-boolean condition in if statement
	// Hence x Is Not Boolean Expression
	// if x {
	if itob( x )  {
		fmt.Println("If Block")
	} else {
		fmt.Println("Else Block")
	}
}

//___________________________________________________________
//___________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!
// import "time"

func playWithSwitches() {
    i := 2
    fmt.Print("Write ", i, " as ")
    // break Is Implicit In switch
    switch i {
    case 1:
        fmt.Println("one")
    case 2:
        fmt.Println("two")
    case 3:
        fmt.Println("three")
    }

    switch time.Now().Weekday() {
    case time.Saturday, time.Sunday:
        fmt.Println("It's the weekend")
    default:
        fmt.Println("It's a weekday")
    }

    t := time.Now()
    switch {
    case t.Hour() < 12:
        fmt.Println("It's before noon")
    default:
        fmt.Println("It's after noon")
    }
}

//___________________________________________________________
//___________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func playWithTypeConversion() {
	var i, j int = 10, 10
	const (
		cells = 100
		xyrange = 30.0
	) 

	x := xyrange * ( float64( i ) / cells - 0.5 )
	y := xyrange * ( float64( j ) / cells - 0.5 )

	fmt.Printf("Values : %v %v", x, y)

	var ii, jj int = 10, 10
	var cells1 int  = 100
	var xyrange1 float64  = 30.0
// ./GoFoundation.go:352:21: invalid operation: 
//		float64(ii) / cells1 (mismatched types float64 and int)
// ./GoFoundation.go:353:21: invalid operation: 
//		float64(jj) / cells1 (mismatched types float64 and int)

	xx := xyrange1 * ( float64( ii ) / cells1 - 0.5 )
	yy := xyrange1 * ( float64( jj ) / cells1 - 0.5 )

	fmt.Printf("Values : %v %v", xx, yy)
}

//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________



func main() {
	fmt.Println("\nFunction : helloWorld")
	helloWorld()

	fmt.Println("\nFunction : playWithConstantValriables")
	playWithConstantValriables()

	fmt.Println("\nFunction : playWithDataTypes")
	playWithDataTypes()

	fmt.Println("\nFunction : playWithConstants")
	playWithConstants()

	fmt.Println("\nFunction : playWithForLoop")
	// Passing Command Line Arguments
	playWithForLoop( os.Args )

	fmt.Println("\nFunction : playWithFlagPackage")
	playWithFlagPackage()

	fmt.Println("\nFunction : playWithFormatSpecifiers")
	playWithFormatSpecifiers()

	fmt.Println("\nFunction : playWithIfElse")
	playWithIfElse()

	fmt.Println("\nFunction : playWithIfElseAgain")
	playWithIfElseAgain()

	fmt.Println("\nFunction : playWithSwitches")
	playWithSwitches()

	fmt.Println("\nFunction : playWithTypeConversion")
	playWithTypeConversion()

	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
}
