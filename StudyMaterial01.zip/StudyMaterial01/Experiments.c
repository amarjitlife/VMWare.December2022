
#include <stdio.h>
#include <limits.h>

// BAD DESIGN
int unsafeSum( int x, int y ) {
	return x + y;
}

//_________________________________________________________


// GOOD DESIGN
// Platform Independent Code
//		Type Safe Code
signed int sum(signed int x, signed int y) {
	  signed int sum = 0;
	  // Type Safe Code
	  //	Respect Type Definition
	  if (((y > 0) && (x > (INT_MAX - y))) ||
	      ((y < 0) && (x < (INT_MIN - y)))) {
			printf("\nCan't Calculate Sum For Given Values");
	  } else {
			sum = x + y;
			return sum;
	  }
}

//_________________________________________________________

// ASCII CODE
char ch = 'A';

void playWithIfElse() {
	// char thirdBit = ch & 0000100;
	int x = -10;

	// Value To Value Conversion Happening
	//		int Value Getting Converted To Boolean Value

	// Expression Evaluated To Non Zero int Value
	//		It's Converted To True
	// Expression Evaluated To Zero int Value
	//		It's Converted To False

	// if (Expression) { } else { }
	// if ( x = 100 ) {

	if ( x ) {
		printf("\nOye Hoye!!!");
	} else {
		printf("\nWah Wah!!!");
	}
}

void playWithIfElseAgain() {
	int x = -10;
	int y = 0;

	if ( x ) {  y = 99; } else { y = 111; }

	y = ( x ) ?  99 : 111;
}

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________

int main() {
	printf("\n Function : playWithIfElse");
	playWithIfElse();

	printf("\n Function : playWithIfElseAgain");
	playWithIfElseAgain();

	// printf("\n Function : ");
	// printf("\n Function : ");
	// printf("\n Function : ");
	// printf("\n Function : ");
	// printf("\n Function : ");
	// printf("\n Function : ");
	// printf("\n Function : ");
	// printf("\n Function : ");
	// printf("\n Function : ");
	// printf("\n Function : ");
	// printf("\n Function : ");	
}