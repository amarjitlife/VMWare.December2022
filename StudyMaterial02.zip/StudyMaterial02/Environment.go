____________________________________________________________

GO ENVIRONMENT GENERIC
____________________________________________________________

01. Download Go Compiler
	https://go.dev/dl/

	Download Go Compiler 
		As Per Your Operating System and Architecture

02. Install Go Compiler		
	For Windows/MacOSX
		Click On Go Compiler Executable To Install


	For Linux Machine
		Download
			Linux 2.6.32 or later, Intel 64-bit processor
			go1.19.4.linux-amd64.tar.gz (142MB)

		Extract It
			tar -xvzf go1.19.4.linux-amd64.tar.gz

			It Will Extract Go Compiler In
				go Directory

03. Add Go Compiler To PATH Variable 

	export PATH=$PATH:YOUR_PATH/go/bin


____________________________________________________________

MAC MACHINE ENVIRONMENT
____________________________________________________________

	Install HomeBrew Package Manager
		/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

	brew install go

____________________________________________________________

LINUX UBUNTU 
____________________________________________________________

	sudo apt install golang-go

____________________________________________________________

CHECKING GO INSTALLATION
____________________________________________________________

	go version

		go version go1.18.1 linux/amd64

____________________________________________________________

RUNNING HELLO WORLD
____________________________________________________________

1. Create Hello.go File With Following Code

	package main

	import "fmt"

	func main() {
		fmt.Println("Hello, 世界")
	}

2. Save This File Hello.go In Documents/LearnGo Directory

	cd YOUR_PATH/Documents/LearnGo/
	
	Build and Run
		go build Hello.go
		./Hello

	Directly Running
		go run Hello.go

____________________________________________________________
____________________________________________________________
____________________________________________________________
____________________________________________________________
____________________________________________________________
____________________________________________________________
